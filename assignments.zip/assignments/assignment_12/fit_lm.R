### fit_lm.R

#The important variables are: 4, 8, 9, 11
important.variables <- c(1, 4, 5, 8, 9)
data <- data[, important.variables]

lm.object <- lm(y~., data=data)
summary(lm.object)
coef(lm.object)
