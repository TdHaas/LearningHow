### analysis.R

source("data_generation.R")
data <- GenerateData(N=100, P=10)
plot(lm.object)

