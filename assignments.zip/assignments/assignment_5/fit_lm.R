### fit_lm.R

#The important variables are: 2, 4, 5, 9
important.variables <- c(1, 2, 5, 8, 9)
data <- data[, important.variables]

lm.object <- lm(y~., data=data)
summary(lm.object)
coef(lm.object)
