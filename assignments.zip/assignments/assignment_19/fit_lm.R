### fit_lm.R

#The important variables are: 3, 6, 8, 9
important.variables <- c(1, 3, 6, 7, 9)
data <- data[, important.variables]

lm.object <- lm(y~., data=data)
summary(lm.object)
coef(lm.object)
