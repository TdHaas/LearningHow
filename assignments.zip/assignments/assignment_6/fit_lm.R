### fit_lm.R

#The important variables are: 4, 6, 7, 10
important.variables <- c(1, 3, 6, 7, 10)
data <- data[, important.variables]

lm.object <- lm(y~., data=data)
summary(lm.object)
coef(lm.object)
